﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class enumset
    {
        public enum invenchoice
        {
            traning = 1,
            iron = 2,
            sp1 = 3,
            old = 4,
            bronze = 5,
            sp2 = 6
        }

        public enum Job
        {
            전사 = 1,
            마법사 = 2,
            궁수 = 3
        }

        public enum lobbychoice
        {
            Status = 1,
            Inventory = 2,
            Shop = 3,
            Rest = 4
        }

    }
}
