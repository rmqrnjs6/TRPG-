﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class StartGameset
    {
        public void StartGame()
        {
            Initset init = new Initset();
            init.Init();
        }
    }
}
