﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class itemstatus
    {
        public int TrainingDeffensivePower = 5;
        public int TtrainingGlod = 1000;

        public int IronDeffensivePower = 9;
        public int IronGlod = 1500;

        public int SpartarDeffensivePower = 15;
        public int SpartarGold = 3500;

        public int AlphaMaleDeffensivePower = 999;
        public int AlphaMaleGold = 1000000;

        public int OldSwordOffensivePower = 2;
        public int OldSwordGold = 600;

        public int BronzeSwordOffensivePower = 5;
        public int BronzeSwordGold = 1500;

        public int SpartarSpearOffensivePower = 7;
        public int SpartarSpearGold = 2100;

        public int AlphaMaleSwordOffensivePower = 999;
        public int AlphaMaleSwordGold = 1000000;

    }

}
