﻿using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace ConsoleApp3
{
    public class Program
    {
        static void Main(string[] args)
        { 
            StartGameset start = new StartGameset();
            start.StartGame();
        }
    }
}



 
    








