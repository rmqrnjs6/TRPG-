﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class GameLogic
    {
        private Player _player;
        private itemstatus _item;
        private Inventory _inven;

        private bool _isGameOver = false;
    }

}
